# Insight Bucket List (Containerize)

## Requirements

- Docker Compose
- Yarn

## Install

0. Install node modules:

```
cd insights-server && yarn
cd ..
cd insights-web && yarn
cd ..
```

1. Create containers:

```
yarn dev:install
```

## Dev

4. Run the project

```
yarn dev:up
```

Visit [localhost](http://localhost)