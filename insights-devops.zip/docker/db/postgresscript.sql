CREATE USER test WITH PASSWORD 'test' CREATEDB;
CREATE DATABASE insights4
    WITH 
    OWNER = test
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.utf8'
    LC_CTYPE = 'en_US.utf8'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;


    -- Table: public.audit

-- DROP TABLE public.audit;

CREATE TABLE public.audit
(
    "createdAt" timestamp without time zone NOT NULL DEFAULT now(),
    "updatedAt" timestamp without time zone NOT NULL DEFAULT now(),
    _ver integer,
    id integer NOT NULL DEFAULT nextval('audit_id_seq'::regclass),
    "objectId" character varying COLLATE pg_catalog."default" NOT NULL,
    "objectType" character varying COLLATE pg_catalog."default",
    "objectValue" character varying COLLATE pg_catalog."default",
    "userId" character varying COLLATE pg_catalog."default",
    CONSTRAINT "PK_1d3d120ddaf7bc9b1ed68ed463a" PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.audit
    OWNER to test;